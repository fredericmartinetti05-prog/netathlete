export const SPORTS = [
  "Football", "Basketball", "Tennis", "Volleyball", "Rugby", "Baseball",
  "Hockey", "Athletics", "Swimming", "Cycling", "Boxing", "MMA",
  "Golf", "Cricket", "Handball", "Other"
];

export const LEVELS = ["Amateur", "Semi-Pro", "Professional", "Youth Academy", "College/University"];

export const AVAILABILITY = ["Available", "Open to offers", "Under contract", "Not available"];

export const ROLES = [
  { value: "athlete", label: "Athlete", description: "Showcase your talent" },
  { value: "sports_professional", label: "Sports Professional", description: "Coach, scout, agent" },
  { value: "club", label: "Club / Organization", description: "Recruit talent" },
  { value: "sports_brand", label: "Sports Brand", description: "Sponsor athletes" },
] as const;

export type RoleValue = typeof ROLES[number]["value"];

export function calculateAge(dob: string | null): number | null {
  if (!dob) return null;
  const d = new Date(dob);
  const diff = Date.now() - d.getTime();
  return Math.floor(diff / (1000 * 60 * 60 * 24 * 365.25));
}