import { BadgeCheck, Clock, XCircle } from "lucide-react";
import { cn } from "@/lib/utils";

type Status = "not_requested" | "pending" | "approved" | "rejected";

export function CertificationBadge({ status, size = "sm" }: { status: Status; size?: "sm" | "md" }) {
  if (status === "not_requested") return null;
  const config = {
    approved: { icon: BadgeCheck, label: "Certified", className: "bg-gradient-certified text-certified-foreground" },
    pending: { icon: Clock, label: "Pending", className: "bg-muted text-muted-foreground" },
    rejected: { icon: XCircle, label: "Rejected", className: "bg-destructive/20 text-destructive" },
  }[status];
  const Icon = config.icon;
  return (
    <span className={cn("inline-flex items-center gap-1 rounded-full font-semibold",
      size === "sm" ? "text-[10px] px-2 py-0.5" : "text-xs px-2.5 py-1",
      config.className)}>
      <Icon className={size === "sm" ? "h-3 w-3" : "h-3.5 w-3.5"} />
      {config.label}
    </span>
  );
}

export function RoleBadge({ role }: { role: string | null }) {
  if (!role) return null;
  const labels: Record<string, string> = {
    athlete: "Athlete",
    sports_professional: "Pro",
    club: "Club",
    sports_brand: "Brand",
    admin: "Admin",
  };
  return (
    <span className="inline-flex items-center rounded-full bg-secondary text-secondary-foreground text-[10px] font-medium px-2 py-0.5 uppercase tracking-wider">
      {labels[role] ?? role}
    </span>
  );
}