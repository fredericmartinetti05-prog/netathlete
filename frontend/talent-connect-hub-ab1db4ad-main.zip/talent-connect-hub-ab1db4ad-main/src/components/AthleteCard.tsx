import { Link } from "react-router-dom";
import { MapPin, Trophy, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CertificationBadge, RoleBadge } from "./CertificationBadge";
import { calculateAge } from "@/lib/constants";

export interface AthleteRow {
  id: string;
  name: string | null;
  role: string | null;
  country: string | null;
  city: string | null;
  certification_status: "not_requested" | "pending" | "approved" | "rejected";
  sport?: string | null;
  position?: string | null;
  level?: string | null;
  current_club?: string | null;
  availability?: string | null;
  date_of_birth?: string | null;
  video_links?: string[] | null;
}

export function AthleteCard({ athlete }: { athlete: AthleteRow }) {
  const age = calculateAge(athlete.date_of_birth ?? null);
  const initials = (athlete.name ?? "?").split(" ").map(s => s[0]).slice(0, 2).join("").toUpperCase();

  return (
    <div className="group rounded-2xl bg-card border border-border p-5 shadow-card hover:border-primary/50 transition-all">
      <div className="flex items-start gap-4">
        <div className="h-14 w-14 rounded-xl bg-gradient-primary flex items-center justify-center text-primary-foreground font-display font-bold text-lg shrink-0">
          {initials}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <h3 className="font-display font-semibold text-base truncate">{athlete.name ?? "Unnamed"}</h3>
              <div className="flex items-center gap-1.5 mt-1 flex-wrap">
                <RoleBadge role={athlete.role} />
                <CertificationBadge status={athlete.certification_status} />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-4 space-y-1.5 text-sm">
        {athlete.sport && (
          <div className="flex items-center gap-2 text-foreground">
            <Trophy className="h-3.5 w-3.5 text-primary" />
            <span className="font-medium">{athlete.sport}</span>
            {athlete.position && <span className="text-muted-foreground">· {athlete.position}</span>}
            {age !== null && <span className="text-muted-foreground tabular">· {age}y</span>}
          </div>
        )}
        {(athlete.city || athlete.country) && (
          <div className="flex items-center gap-2 text-muted-foreground">
            <MapPin className="h-3.5 w-3.5" />
            {[athlete.city, athlete.country].filter(Boolean).join(", ")}
          </div>
        )}
        {athlete.current_club && (
          <div className="text-muted-foreground text-xs">@ {athlete.current_club}</div>
        )}
        {athlete.level && (
          <div className="inline-flex items-center text-[10px] uppercase tracking-wider font-semibold text-success">
            {athlete.level}
          </div>
        )}
      </div>

      <div className="mt-4 flex gap-2">
        <Button asChild variant="default" size="sm" className="flex-1">
          <Link to={`/profile/${athlete.id}`}>View profile</Link>
        </Button>
        <Button asChild variant="outline" size="sm">
          <Link to={`/messages/${athlete.id}`}>
            <MessageSquare className="h-4 w-4" />
          </Link>
        </Button>
      </div>
    </div>
  );
}