import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Index from "./pages/Index.tsx";
import NotFound from "./pages/NotFound.tsx";
import Login from "./pages/auth/Login";
import Signup from "./pages/auth/Signup";
import ForgotPassword from "./pages/auth/ForgotPassword";
import ResetPassword from "./pages/auth/ResetPassword";
import RoleSelection from "./pages/onboarding/RoleSelection";
import Dashboard from "./pages/Dashboard";
import ProfileEdit from "./pages/ProfileEdit";
import ProfileDetail from "./pages/ProfileDetail";
import Search from "./pages/Search";
import Messages from "./pages/Messages";
import Privacy from "./pages/Privacy";
import Certification from "./pages/Certification";
import Admin from "./pages/Admin";
import { AuthProvider } from "./hooks/useAuth";
import { ProtectedRoute } from "./components/ProtectedRoute";
import { AppShell } from "./components/AppShell";

const queryClient = new QueryClient();

const Shell = ({ children }: { children: React.ReactNode }) => (
  <ProtectedRoute><AppShell>{children}</AppShell></ProtectedRoute>
);

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/auth/login" element={<Login />} />
            <Route path="/auth/signup" element={<Signup />} />
            <Route path="/auth/forgot" element={<ForgotPassword />} />
            <Route path="/auth/reset-password" element={<ResetPassword />} />
            <Route path="/onboarding/role" element={<ProtectedRoute><RoleSelection /></ProtectedRoute>} />

            <Route path="/dashboard" element={<Shell><Dashboard /></Shell>} />
            <Route path="/profile/edit" element={<Shell><ProfileEdit /></Shell>} />
            <Route path="/profile/:userId" element={<Shell><ProfileDetail /></Shell>} />
            <Route path="/search" element={<Shell><Search /></Shell>} />
            <Route path="/messages" element={<Shell><Messages /></Shell>} />
            <Route path="/messages/:userId" element={<Shell><Messages /></Shell>} />
            <Route path="/privacy" element={<Shell><Privacy /></Shell>} />
            <Route path="/certification" element={<Shell><Certification /></Shell>} />
            <Route path="/admin" element={<ProtectedRoute adminOnly><AppShell><Admin /></AppShell></ProtectedRoute>} />

            <Route path="*" element={<NotFound />} />
          </Routes>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
