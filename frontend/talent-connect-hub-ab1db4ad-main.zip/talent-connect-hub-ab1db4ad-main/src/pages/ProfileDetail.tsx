import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { MapPin, Trophy, MessageSquare, FileText, Video, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { CertificationBadge, RoleBadge } from "@/components/CertificationBadge";
import { calculateAge } from "@/lib/constants";
import { useAuth } from "@/hooks/useAuth";

export default function ProfileDetail() {
  const { userId } = useParams();
  const { user } = useAuth();
  const [data, setData] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    if (!userId) return;
    (async () => {
      const { data: p } = await supabase.from("profiles").select("*").eq("id", userId).maybeSingle();
      if (!p) { setNotFound(true); setLoading(false); return; }
      const { data: a } = await supabase.from("athlete_profiles").select("*").eq("user_id", userId).maybeSingle();
      setData({ ...p, athlete: a });
      setLoading(false);
    })();
  }, [userId]);

  if (loading) return <div className="p-10 text-muted-foreground">Loading…</div>;
  if (notFound) return <div className="p-10">Profile not found.</div>;

  const isOwner = user?.id === userId;
  const restricted = !isOwner && data.visibility === "connections_only";

  if (!isOwner && data.visibility === "private") {
    return (
      <div className="max-w-2xl mx-auto p-10 text-center">
        <Lock className="mx-auto h-10 w-10 text-muted-foreground" />
        <h1 className="font-display font-bold text-2xl mt-4">This profile is private</h1>
        <p className="text-muted-foreground mt-2">The owner has chosen to hide this profile.</p>
      </div>
    );
  }

  const a = data.athlete;
  const age = calculateAge(a?.date_of_birth);
  const initials = (data.name ?? "?").split(" ").map((s: string)=>s[0]).slice(0,2).join("").toUpperCase();

  return (
    <div className="max-w-4xl mx-auto p-6 md:p-10">
      <div className="rounded-2xl border border-border bg-card p-6 md:p-8 shadow-card">
        <div className="flex flex-col md:flex-row md:items-center gap-6">
          <div className="h-24 w-24 rounded-2xl bg-gradient-primary flex items-center justify-center text-primary-foreground font-display font-bold text-3xl">
            {initials}
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <RoleBadge role={data.role} />
              <CertificationBadge status={data.certification_status} size="md" />
            </div>
            <h1 className="font-display font-bold text-3xl md:text-4xl mt-2">{data.name}</h1>
            <div className="flex items-center gap-4 text-sm text-muted-foreground mt-2 flex-wrap">
              {(data.city || data.country) && (
                <span className="flex items-center gap-1.5"><MapPin className="h-4 w-4" />{[data.city, data.country].filter(Boolean).join(", ")}</span>
              )}
              {a?.sport && <span className="flex items-center gap-1.5"><Trophy className="h-4 w-4" />{a.sport}{a.position && ` · ${a.position}`}</span>}
              {age !== null && <span className="tabular">{age} years</span>}
            </div>
          </div>
          {!isOwner && (
            <div className="flex gap-2">
              <Button asChild><Link to={`/messages/${userId}`}><MessageSquare className="h-4 w-4 mr-2" />Message</Link></Button>
            </div>
          )}
        </div>
      </div>

      {restricted ? (
        <div className="mt-6 rounded-2xl border border-border bg-card p-8 text-center">
          <Lock className="mx-auto h-8 w-8 text-muted-foreground" />
          <p className="mt-3 text-muted-foreground">Full profile visible to connections only.</p>
        </div>
      ) : (
        <>
          <div className="grid md:grid-cols-3 gap-4 mt-6">
            <Stat label="Level" value={a?.level} />
            <Stat label="Availability" value={a?.availability} />
            <Stat label="Current club" value={a?.current_club} />
            <Stat label="Height" value={a?.height ? `${a.height} cm` : null} />
            <Stat label="Weight" value={a?.weight ? `${a.weight} kg` : null} />
          </div>

          {a?.achievements && <Block title="Achievements">{a.achievements}</Block>}
          {a?.statistics && <Block title="Statistics">{a.statistics}</Block>}

          {(a?.video_links?.length ?? 0) > 0 && (
            <div className="mt-6 rounded-2xl border border-border bg-card p-6">
              <h3 className="font-display font-semibold flex items-center gap-2"><Video className="h-4 w-4 text-primary"/>Videos</h3>
              <ul className="mt-3 space-y-2">
                {a!.video_links!.map((v: string, i: number) => (
                  <li key={i}><a href={v} target="_blank" rel="noreferrer" className="text-primary hover:underline text-sm break-all">{v}</a></li>
                ))}
              </ul>
            </div>
          )}

          {a?.sports_cv_link && (
            <div className="mt-6 rounded-2xl border border-border bg-card p-6">
              <h3 className="font-display font-semibold flex items-center gap-2"><FileText className="h-4 w-4 text-primary"/>Sports CV</h3>
              <Button asChild variant="outline" className="mt-3">
                <a href={a.sports_cv_link} target="_blank" rel="noreferrer">View CV</a>
              </Button>
            </div>
          )}
        </>
      )}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string | number | null | undefined }) {
  if (!value) return null;
  return (
    <div className="rounded-2xl border border-border bg-card p-4">
      <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="font-display font-semibold text-lg mt-1 tabular">{value}</div>
    </div>
  );
}

function Block({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mt-6 rounded-2xl border border-border bg-card p-6">
      <h3 className="font-display font-semibold">{title}</h3>
      <p className="mt-2 text-sm whitespace-pre-wrap text-muted-foreground">{children}</p>
    </div>
  );
}