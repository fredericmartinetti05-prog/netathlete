import { useEffect, useState } from "react";
import { Award, BadgeCheck, Clock, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";

type Status = "not_requested" | "pending" | "approved" | "rejected";

export default function Certification() {
  const { user } = useAuth();
  const [status, setStatus] = useState<Status>("not_requested");
  const [message, setMessage] = useState("");
  const [doc, setDoc] = useState("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!user) return;
    supabase.from("profiles").select("certification_status").eq("id", user.id).maybeSingle()
      .then(({ data }) => data?.certification_status && setStatus(data.certification_status));
  }, [user]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setSubmitting(true);
    const { error: cErr } = await supabase.from("certification_requests").insert({
      user_id: user.id, message: message.trim() || null, document_link: doc.trim() || null, status: "pending",
    });
    const { error: pErr } = await supabase.from("profiles").update({ certification_status: "pending" }).eq("id", user.id);
    setSubmitting(false);
    if (cErr || pErr) return toast.error((cErr ?? pErr)?.message ?? "Error");
    setStatus("pending");
    setMessage(""); setDoc("");
    toast.success("Certification request submitted");
  };

  const StatusCard = () => {
    if (status === "approved") return <Banner icon={BadgeCheck} title="You are certified" tone="success" description="Your profile has been verified. The badge appears on your profile and in search."/>;
    if (status === "pending") return <Banner icon={Clock} title="Request pending" tone="muted" description="An admin will review your request soon." />;
    if (status === "rejected") return <Banner icon={XCircle} title="Request rejected" tone="destructive" description="You can submit a new request below with more information." />;
    return null;
  };

  const canSubmit = status === "not_requested" || status === "rejected";

  return (
    <div className="max-w-2xl mx-auto p-6 md:p-10">
      <div className="flex items-center gap-3">
        <Award className="h-6 w-6 text-certified" />
        <h1 className="font-display font-bold text-3xl">Certification</h1>
      </div>
      <p className="text-muted-foreground mt-1">Get your profile verified to stand out to clubs and scouts.</p>

      <div className="mt-6"><StatusCard /></div>

      {canSubmit && (
        <form onSubmit={submit} className="mt-6 rounded-2xl border border-border bg-card p-6 space-y-4">
          <div className="space-y-1.5">
            <Label>Message (optional)</Label>
            <Textarea rows={4} maxLength={1000} value={message} onChange={e=>setMessage(e.target.value)} placeholder="Why should your profile be certified?" />
          </div>
          <div className="space-y-1.5">
            <Label>Document link (optional)</Label>
            <Input value={doc} onChange={e=>setDoc(e.target.value)} placeholder="https://… (ID, license, contract)" />
          </div>
          <Button type="submit" disabled={submitting}>{submitting ? "Submitting…" : "Submit request"}</Button>
        </form>
      )}
    </div>
  );
}

function Banner({ icon: Icon, title, description, tone }: { icon: React.ComponentType<{ className?: string }>; title: string; description: string; tone: "success" | "muted" | "destructive" }) {
  const cls = tone === "success" ? "border-certified/40 bg-certified/5" : tone === "destructive" ? "border-destructive/40 bg-destructive/5" : "border-border bg-card";
  const iconCls = tone === "success" ? "text-certified" : tone === "destructive" ? "text-destructive" : "text-muted-foreground";
  return (
    <div className={`rounded-2xl border p-5 flex gap-4 ${cls}`}>
      <Icon className={`h-6 w-6 shrink-0 ${iconCls}`} />
      <div>
        <div className="font-display font-semibold">{title}</div>
        <p className="text-sm text-muted-foreground mt-1">{description}</p>
      </div>
    </div>
  );
}