import { useEffect, useState } from "react";
import { Search as SearchIcon, SlidersHorizontal } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { AthleteCard, AthleteRow } from "@/components/AthleteCard";
import { EmptyState } from "@/components/EmptyState";
import { SPORTS, LEVELS, AVAILABILITY, calculateAge } from "@/lib/constants";

const ANY = "__any__";

export default function Search() {
  const [filters, setFilters] = useState({
    q: "", sport: ANY, position: "", country: "", city: "",
    level: ANY, availability: ANY, ageMin: "", ageMax: "", hasVideo: false,
  });
  const [results, setResults] = useState<AthleteRow[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchResults = async () => {
    setLoading(true);
    let query = supabase
      .from("profiles")
      .select("id, name, role, country, city, certification_status, visibility, athlete_profiles(sport, position, level, current_club, availability, date_of_birth, video_links)")
      .eq("visibility", "public")
      .eq("status", "active")
      .limit(60);

    if (filters.q) query = query.ilike("name", `%${filters.q}%`);
    if (filters.country) query = query.ilike("country", `%${filters.country}%`);
    if (filters.city) query = query.ilike("city", `%${filters.city}%`);

    const { data, error } = await query;
    setLoading(false);
    if (error) return;
    const flat: AthleteRow[] = (data ?? []).map((r: any) => {
      const a = Array.isArray(r.athlete_profiles) ? r.athlete_profiles[0] : r.athlete_profiles;
      return {
        id: r.id, name: r.name, role: r.role, country: r.country, city: r.city,
        certification_status: r.certification_status,
        sport: a?.sport, position: a?.position, level: a?.level,
        current_club: a?.current_club, availability: a?.availability,
        date_of_birth: a?.date_of_birth, video_links: a?.video_links,
      };
    }).filter((r) => {
      if (filters.sport !== ANY && r.sport !== filters.sport) return false;
      if (filters.position && !r.position?.toLowerCase().includes(filters.position.toLowerCase())) return false;
      if (filters.level !== ANY && r.level !== filters.level) return false;
      if (filters.availability !== ANY && r.availability !== filters.availability) return false;
      if (filters.hasVideo && !(r.video_links && r.video_links.length > 0)) return false;
      const age = calculateAge(r.date_of_birth ?? null);
      if (filters.ageMin && (age === null || age < Number(filters.ageMin))) return false;
      if (filters.ageMax && (age === null || age > Number(filters.ageMax))) return false;
      return true;
    });
    setResults(flat);
  };

  useEffect(() => { fetchResults(); }, []); // initial load

  return (
    <div className="max-w-6xl mx-auto p-6 md:p-10">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display font-bold text-3xl">Talent search</h1>
          <p className="text-muted-foreground mt-1">Find athletes by sport, position, age, location and more.</p>
        </div>
      </div>

      <div className="mt-6 rounded-2xl border border-border bg-card p-5 space-y-4">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input className="pl-9" placeholder="Search by name" value={filters.q} onChange={e=>setFilters({...filters, q: e.target.value})} />
          </div>
          <Button onClick={fetchResults}><SlidersHorizontal className="h-4 w-4 mr-2" />Apply</Button>
        </div>

        <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-3">
          <FilterSelect label="Sport" value={filters.sport} onChange={v=>setFilters({...filters, sport: v})} options={SPORTS} />
          <FilterSelect label="Level" value={filters.level} onChange={v=>setFilters({...filters, level: v})} options={LEVELS} />
          <FilterSelect label="Availability" value={filters.availability} onChange={v=>setFilters({...filters, availability: v})} options={AVAILABILITY} />
          <div className="space-y-1">
            <Label className="text-xs">Position</Label>
            <Input placeholder="e.g. Striker" value={filters.position} onChange={e=>setFilters({...filters, position: e.target.value})} />
          </div>
          <div className="space-y-1">
            <Label className="text-xs">Country</Label>
            <Input value={filters.country} onChange={e=>setFilters({...filters, country: e.target.value})} />
          </div>
          <div className="space-y-1">
            <Label className="text-xs">City</Label>
            <Input value={filters.city} onChange={e=>setFilters({...filters, city: e.target.value})} />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1">
              <Label className="text-xs">Min age</Label>
              <Input type="number" value={filters.ageMin} onChange={e=>setFilters({...filters, ageMin: e.target.value})} />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Max age</Label>
              <Input type="number" value={filters.ageMax} onChange={e=>setFilters({...filters, ageMax: e.target.value})} />
            </div>
          </div>
          <label className="flex items-end gap-2 cursor-pointer pb-2">
            <Checkbox checked={filters.hasVideo} onCheckedChange={(v)=>setFilters({...filters, hasVideo: !!v})} />
            <span className="text-sm">Has videos</span>
          </label>
        </div>
      </div>

      <div className="mt-6">
        {loading ? (
          <p className="text-muted-foreground">Searching…</p>
        ) : results.length === 0 ? (
          <EmptyState icon={SearchIcon} title="No athletes match your filters" description="Try widening your search criteria." />
        ) : (
          <>
            <p className="text-sm text-muted-foreground mb-3">{results.length} result{results.length !== 1 && "s"}</p>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {results.map(r => <AthleteCard key={r.id} athlete={r} />)}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

function FilterSelect({ label, value, onChange, options }: { label: string; value: string; onChange: (v: string)=>void; options: readonly string[] }) {
  return (
    <div className="space-y-1">
      <Label className="text-xs">{label}</Label>
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger><SelectValue placeholder="Any" /></SelectTrigger>
        <SelectContent>
          <SelectItem value={ANY}>Any</SelectItem>
          {options.map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}
        </SelectContent>
      </Select>
    </div>
  );
}