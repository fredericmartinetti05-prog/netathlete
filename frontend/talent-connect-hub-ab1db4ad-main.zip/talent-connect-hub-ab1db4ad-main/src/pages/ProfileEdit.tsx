import { useEffect, useState } from "react";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { SPORTS, LEVELS, AVAILABILITY } from "@/lib/constants";

export default function ProfileEdit() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    name: "", country: "", city: "",
    sport: "", position: "", level: "", current_club: "",
    availability: "", height: "", weight: "", date_of_birth: "",
    achievements: "", statistics: "", video_links: "", sports_cv_link: "",
  });

  useEffect(() => {
    if (!user) return;
    (async () => {
      const [{ data: p }, { data: a }] = await Promise.all([
        supabase.from("profiles").select("*").eq("id", user.id).maybeSingle(),
        supabase.from("athlete_profiles").select("*").eq("user_id", user.id).maybeSingle(),
      ]);
      setForm({
        name: p?.name ?? "", country: p?.country ?? "", city: p?.city ?? "",
        sport: a?.sport ?? "", position: a?.position ?? "", level: a?.level ?? "",
        current_club: a?.current_club ?? "", availability: a?.availability ?? "",
        height: a?.height?.toString() ?? "", weight: a?.weight?.toString() ?? "",
        date_of_birth: a?.date_of_birth ?? "",
        achievements: a?.achievements ?? "", statistics: a?.statistics ?? "",
        video_links: (a?.video_links ?? []).join(", "), sports_cv_link: a?.sports_cv_link ?? "",
      });
      setLoading(false);
    })();
  }, [user]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    if (!form.name.trim()) return toast.error("Name is required");
    setSaving(true);
    const { error: pErr } = await supabase.from("profiles")
      .update({ name: form.name.trim(), country: form.country || null, city: form.city || null })
      .eq("id", user.id);
    const videoArr = form.video_links.split(",").map(s => s.trim()).filter(Boolean);
    const { error: aErr } = await supabase.from("athlete_profiles").upsert({
      user_id: user.id,
      sport: form.sport || null,
      position: form.position || null,
      level: form.level || null,
      current_club: form.current_club || null,
      availability: form.availability || null,
      height: form.height ? Number(form.height) : null,
      weight: form.weight ? Number(form.weight) : null,
      date_of_birth: form.date_of_birth || null,
      achievements: form.achievements || null,
      statistics: form.statistics || null,
      video_links: videoArr,
      sports_cv_link: form.sports_cv_link || null,
    });
    setSaving(false);
    if (pErr || aErr) return toast.error((pErr ?? aErr)?.message ?? "Save failed");
    toast.success("Profile saved");
    navigate(`/profile/${user.id}`);
  };

  if (loading) return <div className="p-10 text-muted-foreground">Loading…</div>;

  return (
    <div className="max-w-3xl mx-auto p-6 md:p-10">
      <h1 className="font-display font-bold text-3xl">Edit profile</h1>
      <p className="text-muted-foreground mt-1">Build your sports CV. Profiles with videos and stats get more views.</p>

      <form onSubmit={handleSubmit} className="mt-8 space-y-8">
        <Section title="Basic info">
          <Field label="Full name *"><Input value={form.name} onChange={e=>setForm({...form, name: e.target.value})} maxLength={100} /></Field>
          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="Country"><Input value={form.country} onChange={e=>setForm({...form, country: e.target.value})} /></Field>
            <Field label="City"><Input value={form.city} onChange={e=>setForm({...form, city: e.target.value})} /></Field>
          </div>
          <Field label="Date of birth"><Input type="date" value={form.date_of_birth} onChange={e=>setForm({...form, date_of_birth: e.target.value})} /></Field>
        </Section>

        <Section title="Sport">
          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="Sport">
              <Select value={form.sport} onValueChange={v=>setForm({...form, sport: v})}>
                <SelectTrigger><SelectValue placeholder="Select sport" /></SelectTrigger>
                <SelectContent>{SPORTS.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
              </Select>
            </Field>
            <Field label="Position"><Input value={form.position} onChange={e=>setForm({...form, position: e.target.value})} placeholder="e.g. Striker" /></Field>
            <Field label="Level">
              <Select value={form.level} onValueChange={v=>setForm({...form, level: v})}>
                <SelectTrigger><SelectValue placeholder="Select level" /></SelectTrigger>
                <SelectContent>{LEVELS.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
              </Select>
            </Field>
            <Field label="Availability">
              <Select value={form.availability} onValueChange={v=>setForm({...form, availability: v})}>
                <SelectTrigger><SelectValue placeholder="Select availability" /></SelectTrigger>
                <SelectContent>{AVAILABILITY.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
              </Select>
            </Field>
            <Field label="Current club"><Input value={form.current_club} onChange={e=>setForm({...form, current_club: e.target.value})} /></Field>
            <Field label="Height (cm)"><Input type="number" value={form.height} onChange={e=>setForm({...form, height: e.target.value})} /></Field>
            <Field label="Weight (kg)"><Input type="number" value={form.weight} onChange={e=>setForm({...form, weight: e.target.value})} /></Field>
          </div>
        </Section>

        <Section title="Showcase">
          <Field label="Achievements"><Textarea rows={4} maxLength={2000} value={form.achievements} onChange={e=>setForm({...form, achievements: e.target.value})} placeholder="Titles, awards, milestones…" /></Field>
          <Field label="Statistics"><Textarea rows={4} maxLength={2000} value={form.statistics} onChange={e=>setForm({...form, statistics: e.target.value})} placeholder="Goals, assists, PRs, season stats…" /></Field>
          <Field label="Video links" hint="Comma-separated URLs (YouTube, Vimeo…)"><Input value={form.video_links} onChange={e=>setForm({...form, video_links: e.target.value})} placeholder="https://…, https://…" /></Field>
          <Field label="Sports CV link"><Input value={form.sports_cv_link} onChange={e=>setForm({...form, sports_cv_link: e.target.value})} placeholder="https://…" /></Field>
        </Section>

        <div className="flex gap-2">
          <Button type="submit" disabled={saving}>{saving ? "Saving…" : "Save profile"}</Button>
          <Button type="button" variant="outline" onClick={()=>navigate(`/profile/${user?.id}`)}>Preview</Button>
        </div>
      </form>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-6 space-y-4">
      <h2 className="font-display font-semibold text-lg">{title}</h2>
      {children}
    </div>
  );
}

function Field({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      {children}
      {hint && <p className="text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}