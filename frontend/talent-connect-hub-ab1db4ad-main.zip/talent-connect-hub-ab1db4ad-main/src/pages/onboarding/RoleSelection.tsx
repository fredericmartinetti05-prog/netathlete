import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Trophy, Briefcase, Building2, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { ROLES, RoleValue } from "@/lib/constants";
import { cn } from "@/lib/utils";

const icons: Record<RoleValue, typeof Trophy> = {
  athlete: Trophy,
  sports_professional: Briefcase,
  club: Building2,
  sports_brand: Sparkles,
};

export default function RoleSelection() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [selected, setSelected] = useState<RoleValue | null>(null);
  const [loading, setLoading] = useState(false);

  const save = async () => {
    if (!selected || !user) return;
    setLoading(true);
    const { error: pErr } = await supabase.from("profiles").update({ role: selected }).eq("id", user.id);
    const { error: rErr } = await supabase.from("user_roles").insert({ user_id: user.id, role: selected });
    setLoading(false);
    if (pErr || rErr) return toast.error((pErr ?? rErr)?.message ?? "Error");
    toast.success("Role saved");
    if (selected === "athlete") navigate("/profile/edit");
    else navigate("/dashboard");
  };

  return (
    <div className="min-h-screen bg-gradient-hero flex items-center justify-center p-6">
      <div className="max-w-3xl w-full">
        <div className="text-center mb-10">
          <h1 className="font-display font-bold text-3xl md:text-4xl">Choose your role</h1>
          <p className="text-muted-foreground mt-2">This shapes how others discover and connect with you.</p>
        </div>
        <div className="grid sm:grid-cols-2 gap-4">
          {ROLES.map((r) => {
            const Icon = icons[r.value];
            const isSelected = selected === r.value;
            return (
              <button
                key={r.value}
                onClick={() => setSelected(r.value)}
                className={cn(
                  "text-left rounded-2xl border bg-card p-6 transition-all",
                  isSelected ? "border-primary shadow-glow" : "border-border hover:border-primary/40"
                )}
              >
                <Icon className={cn("h-7 w-7 mb-3", isSelected ? "text-primary" : "text-muted-foreground")} />
                <h3 className="font-display font-semibold text-lg">{r.label}</h3>
                <p className="text-sm text-muted-foreground mt-1">{r.description}</p>
              </button>
            );
          })}
        </div>
        <Button className="w-full mt-8 shadow-glow" size="lg" disabled={!selected || loading} onClick={save}>
          {loading ? "Saving..." : "Continue"}
        </Button>
      </div>
    </div>
  );
}