import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Users, BadgeCheck, Flag, Check, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { CertificationBadge, RoleBadge } from "@/components/CertificationBadge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { EmptyState } from "@/components/EmptyState";

type Profile = {
  id: string; email: string | null; name: string | null; role: string | null;
  certification_status: "not_requested"|"pending"|"approved"|"rejected";
  visibility: string; status: string; created_at: string;
};
type CertReq = { id: string; user_id: string; status: string; message: string | null; document_link: string | null; created_at: string; profiles?: { name: string | null; role: string | null } };
type Report = { id: string; reporter_id: string; reported_user_id: string; reason: string; status: string; created_at: string };

export default function Admin() {
  const { user } = useAuth();
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [requests, setRequests] = useState<CertReq[]>([]);
  const [reports, setReports] = useState<Report[]>([]);

  const load = async () => {
    const [{ data: p }, { data: c }, { data: r }] = await Promise.all([
      supabase.from("profiles").select("*").order("created_at", { ascending: false }).limit(100),
      supabase.from("certification_requests").select("*, profiles(name, role)").order("created_at", { ascending: false }),
      supabase.from("reports").select("*").order("created_at", { ascending: false }),
    ]);
    setProfiles((p as Profile[]) ?? []);
    setRequests((c as any) ?? []);
    setReports((r as Report[]) ?? []);
  };

  useEffect(() => { load(); }, []);

  const reviewCert = async (req: CertReq, decision: "approved" | "rejected") => {
    const { error: e1 } = await supabase.from("certification_requests")
      .update({ status: decision, reviewed_by: user?.id, reviewed_at: new Date().toISOString() })
      .eq("id", req.id);
    const { error: e2 } = await supabase.from("profiles").update({ certification_status: decision }).eq("id", req.user_id);
    if (e1 || e2) return toast.error((e1 ?? e2)?.message ?? "Error");
    toast.success(`Request ${decision}`);
    load();
  };

  const resolveReport = async (id: string, status: "resolved" | "dismissed") => {
    const { error } = await supabase.from("reports").update({ status, resolved_at: new Date().toISOString() }).eq("id", id);
    if (error) return toast.error(error.message);
    toast.success(`Report ${status}`);
    load();
  };

  return (
    <div className="max-w-6xl mx-auto p-6 md:p-10">
      <h1 className="font-display font-bold text-3xl">Admin dashboard</h1>
      <p className="text-muted-foreground mt-1">Manage users, certifications and reports.</p>

      <Tabs defaultValue="users" className="mt-8">
        <TabsList>
          <TabsTrigger value="users"><Users className="h-4 w-4 mr-2" />Users <span className="ml-1.5 text-xs opacity-60">{profiles.length}</span></TabsTrigger>
          <TabsTrigger value="certs"><BadgeCheck className="h-4 w-4 mr-2" />Certifications <span className="ml-1.5 text-xs opacity-60">{requests.filter(r=>r.status==="pending").length}</span></TabsTrigger>
          <TabsTrigger value="reports"><Flag className="h-4 w-4 mr-2" />Reports <span className="ml-1.5 text-xs opacity-60">{reports.filter(r=>r.status==="open").length}</span></TabsTrigger>
        </TabsList>

        <TabsContent value="users" className="mt-4">
          <div className="rounded-2xl border border-border bg-card overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/30 text-xs uppercase tracking-wider text-muted-foreground">
                <tr>
                  <Th>Name / Email</Th><Th>Role</Th><Th>Certified</Th><Th>Visibility</Th><Th>Created</Th><Th>Actions</Th>
                </tr>
              </thead>
              <tbody>
                {profiles.map(p => (
                  <tr key={p.id} className="border-t border-border">
                    <Td><div className="font-medium">{p.name ?? "—"}</div><div className="text-xs text-muted-foreground">{p.email}</div></Td>
                    <Td><RoleBadge role={p.role} /></Td>
                    <Td><CertificationBadge status={p.certification_status} /></Td>
                    <Td><span className="capitalize">{p.visibility.replace("_"," ")}</span></Td>
                    <Td className="text-xs text-muted-foreground">{new Date(p.created_at).toLocaleDateString()}</Td>
                    <Td><Button asChild size="sm" variant="outline"><Link to={`/profile/${p.id}`}>View</Link></Button></Td>
                  </tr>
                ))}
              </tbody>
            </table>
            {profiles.length === 0 && <EmptyState icon={Users} title="No users yet" />}
          </div>
        </TabsContent>

        <TabsContent value="certs" className="mt-4">
          <div className="rounded-2xl border border-border bg-card overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/30 text-xs uppercase tracking-wider text-muted-foreground">
                <tr><Th>User</Th><Th>Role</Th><Th>Message</Th><Th>Document</Th><Th>Status</Th><Th>Actions</Th></tr>
              </thead>
              <tbody>
                {requests.map(r => (
                  <tr key={r.id} className="border-t border-border">
                    <Td><Link to={`/profile/${r.user_id}`} className="text-primary hover:underline">{r.profiles?.name ?? r.user_id.slice(0,8)}</Link></Td>
                    <Td><RoleBadge role={r.profiles?.role ?? null} /></Td>
                    <Td className="max-w-xs truncate">{r.message ?? "—"}</Td>
                    <Td>{r.document_link ? <a href={r.document_link} target="_blank" rel="noreferrer" className="text-primary hover:underline">Link</a> : "—"}</Td>
                    <Td><CertificationBadge status={r.status as any} /></Td>
                    <Td>
                      {r.status === "pending" && (
                        <div className="flex gap-1">
                          <Button size="sm" onClick={()=>reviewCert(r, "approved")}><Check className="h-3.5 w-3.5"/></Button>
                          <Button size="sm" variant="outline" onClick={()=>reviewCert(r, "rejected")}><X className="h-3.5 w-3.5"/></Button>
                        </div>
                      )}
                    </Td>
                  </tr>
                ))}
              </tbody>
            </table>
            {requests.length === 0 && <EmptyState icon={BadgeCheck} title="No certification requests" />}
          </div>
        </TabsContent>

        <TabsContent value="reports" className="mt-4">
          <div className="rounded-2xl border border-border bg-card overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/30 text-xs uppercase tracking-wider text-muted-foreground">
                <tr><Th>Reporter</Th><Th>Reported user</Th><Th>Reason</Th><Th>Status</Th><Th>Actions</Th></tr>
              </thead>
              <tbody>
                {reports.map(r => (
                  <tr key={r.id} className="border-t border-border">
                    <Td className="text-xs">{r.reporter_id.slice(0,8)}</Td>
                    <Td><Link to={`/profile/${r.reported_user_id}`} className="text-primary hover:underline text-xs">{r.reported_user_id.slice(0,8)}</Link></Td>
                    <Td>{r.reason}</Td>
                    <Td><span className="capitalize text-xs">{r.status}</span></Td>
                    <Td>
                      {r.status === "open" && (
                        <div className="flex gap-1">
                          <Button size="sm" onClick={()=>resolveReport(r.id, "resolved")}>Resolve</Button>
                          <Button size="sm" variant="outline" onClick={()=>resolveReport(r.id, "dismissed")}>Dismiss</Button>
                        </div>
                      )}
                    </Td>
                  </tr>
                ))}
              </tbody>
            </table>
            {reports.length === 0 && <EmptyState icon={Flag} title="No reports" />}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function Th({ children }: { children: React.ReactNode }) {
  return <th className="text-left p-3 font-semibold">{children}</th>;
}
function Td({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <td className={`p-3 align-middle ${className}`}>{children}</td>;
}