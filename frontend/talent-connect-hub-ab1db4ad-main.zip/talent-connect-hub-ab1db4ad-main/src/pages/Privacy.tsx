import { useEffect, useState } from "react";
import { Eye, Users, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";

type Visibility = "public" | "connections_only" | "private";

const options: { value: Visibility; label: string; description: string; icon: typeof Eye }[] = [
  { value: "public", label: "Public", description: "Visible to all NET Athlete members in search and your profile page.", icon: Eye },
  { value: "connections_only", label: "Connections only", description: "Limited preview in search. Full profile only for connections.", icon: Users },
  { value: "private", label: "Private", description: "Hidden from search and public profile. Only you and admins can see it.", icon: Lock },
];

export default function Privacy() {
  const { user } = useAuth();
  const [visibility, setVisibility] = useState<Visibility>("public");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!user) return;
    supabase.from("profiles").select("visibility").eq("id", user.id).maybeSingle()
      .then(({ data }) => data?.visibility && setVisibility(data.visibility));
  }, [user]);

  const save = async () => {
    if (!user) return;
    setSaving(true);
    const { error } = await supabase.from("profiles").update({ visibility }).eq("id", user.id);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Privacy settings saved");
  };

  return (
    <div className="max-w-2xl mx-auto p-6 md:p-10">
      <h1 className="font-display font-bold text-3xl">Privacy</h1>
      <p className="text-muted-foreground mt-1">Control who can find and view your profile.</p>

      <div className="mt-8 space-y-3">
        {options.map(o => (
          <button
            key={o.value}
            onClick={() => setVisibility(o.value)}
            className={cn("w-full text-left rounded-2xl border p-5 transition flex gap-4 items-start",
              visibility === o.value ? "border-primary bg-card shadow-glow" : "border-border bg-card hover:border-primary/40")}
          >
            <o.icon className={cn("h-5 w-5 mt-0.5", visibility === o.value ? "text-primary" : "text-muted-foreground")} />
            <div>
              <div className="font-display font-semibold">{o.label}</div>
              <p className="text-sm text-muted-foreground mt-1">{o.description}</p>
            </div>
          </button>
        ))}
      </div>
      <Button onClick={save} disabled={saving} className="mt-6">{saving ? "Saving…" : "Save"}</Button>
    </div>
  );
}