import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Search, MessageSquare, Award, User, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { CertificationBadge, RoleBadge } from "@/components/CertificationBadge";

export default function Dashboard() {
  const { user } = useAuth();
  const [profile, setProfile] = useState<{ name: string | null; role: string | null; certification_status: "not_requested"|"pending"|"approved"|"rejected" } | null>(null);
  const [unread, setUnread] = useState(0);

  useEffect(() => {
    if (!user) return;
    supabase.from("profiles").select("name, role, certification_status").eq("id", user.id).maybeSingle()
      .then(({ data }) => setProfile(data));
    supabase.from("messages").select("id", { count: "exact", head: true }).eq("receiver_id", user.id).is("read_at", null)
      .then(({ count }) => setUnread(count ?? 0));
  }, [user]);

  const quickActions = [
    { icon: User, label: "Edit profile", to: "/profile/edit", color: "text-primary" },
    { icon: Search, label: "Search talent", to: "/search", color: "text-success" },
    { icon: MessageSquare, label: "Messages", to: "/messages", color: "text-warning", badge: unread },
    { icon: Award, label: "Get certified", to: "/certification", color: "text-certified" },
  ];

  return (
    <div className="max-w-5xl mx-auto p-6 md:p-10">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <p className="text-sm text-muted-foreground">Welcome back</p>
          <h1 className="font-display font-bold text-3xl md:text-4xl mt-1">{profile?.name ?? "Athlete"}</h1>
          <div className="flex items-center gap-2 mt-2">
            <RoleBadge role={profile?.role ?? null} />
            {profile && <CertificationBadge status={profile.certification_status} />}
          </div>
        </div>
        <Button asChild variant="outline">
          <Link to={`/profile/${user?.id}`}>View public profile <ArrowRight className="ml-1 h-4 w-4" /></Link>
        </Button>
      </div>

      <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {quickActions.map((a) => (
          <Link key={a.to} to={a.to} className="group rounded-2xl border border-border bg-card p-5 hover:border-primary/40 transition shadow-card">
            <div className="flex items-start justify-between">
              <a.icon className={`h-6 w-6 ${a.color}`} />
              {!!a.badge && a.badge > 0 && (
                <span className="text-[10px] font-bold bg-primary text-primary-foreground rounded-full h-5 min-w-[20px] px-1.5 flex items-center justify-center">
                  {a.badge}
                </span>
              )}
            </div>
            <div className="mt-6 font-display font-semibold">{a.label}</div>
            <ArrowRight className="h-4 w-4 mt-1 text-muted-foreground group-hover:translate-x-1 transition" />
          </Link>
        ))}
      </div>

      <div className="mt-10 rounded-2xl border border-border bg-gradient-hero p-8">
        <h2 className="font-display font-bold text-2xl">Get noticed faster</h2>
        <p className="text-muted-foreground mt-2 max-w-xl">
          Complete your athletic profile with videos, statistics and a sports CV. Certified profiles get up to 5× more views from clubs and scouts.
        </p>
        <div className="mt-5 flex gap-2 flex-wrap">
          <Button asChild><Link to="/profile/edit">Complete profile</Link></Button>
          <Button asChild variant="outline"><Link to="/certification">Request certification</Link></Button>
        </div>
      </div>
    </div>
  );
}