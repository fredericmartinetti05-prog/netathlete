import { Link } from "react-router-dom";
import { Trophy, Search, Users, BadgeCheck, MessageSquare, Video, FileText, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const sections = [
  {
    icon: Trophy,
    title: "For Athletes",
    description: "Build a sports CV with videos, stats and achievements. Get discovered by scouts and clubs.",
    accent: "text-primary",
  },
  {
    icon: Search,
    title: "For Clubs & Scouts",
    description: "Search certified talent by sport, position, age and country. Message directly without barriers.",
    accent: "text-success",
  },
  {
    icon: Users,
    title: "For Brands & Professionals",
    description: "Connect with rising athletes and pros. Build long-term partnerships through one network.",
    accent: "text-warning",
  },
];

const features = [
  { icon: BadgeCheck, label: "Verified profiles" },
  { icon: Video, label: "Highlight videos" },
  { icon: FileText, label: "Sports CV" },
  { icon: MessageSquare, label: "Direct messaging" },
];

const Index = () => {
  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Nav */}
      <header className="border-b border-border">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-gradient-primary flex items-center justify-center">
              <Trophy className="h-4 w-4 text-primary-foreground" />
            </div>
            <span className="font-display font-bold text-lg">NET Athlete</span>
          </Link>
          <div className="flex items-center gap-2">
            <Button asChild variant="ghost" size="sm"><Link to="/auth/login">Log in</Link></Button>
            <Button asChild size="sm"><Link to="/auth/signup">Join now</Link></Button>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="bg-gradient-hero">
        <div className="max-w-5xl mx-auto px-6 py-24 md:py-32 text-center">
          <div className="inline-flex items-center gap-2 rounded-full border border-border bg-card/50 backdrop-blur px-3 py-1 text-xs text-muted-foreground mb-8">
            <span className="h-1.5 w-1.5 rounded-full bg-success" />
            The sports network for amateur athletes
          </div>
          <h1 className="font-display font-bold text-5xl md:text-7xl tracking-tight text-balance">
            Connect talent with{" "}
            <span className="bg-gradient-primary bg-clip-text text-transparent">opportunity.</span>
          </h1>
          <p className="mt-6 text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto text-balance">
            A sports network for athletes, clubs, scouts, coaches and sports professionals.
          </p>
          <div className="mt-10 flex flex-col sm:flex-row gap-3 justify-center">
            <Button asChild size="lg" className="shadow-glow">
              <Link to="/auth/signup">Join as Athlete <ArrowRight className="ml-1 h-4 w-4" /></Link>
            </Button>
            <Button asChild size="lg" variant="outline">
              <Link to="/auth/signup">Search Talent</Link>
            </Button>
            <Button asChild size="lg" variant="ghost">
              <Link to="/auth/login">Log in</Link>
            </Button>
          </div>

          <div className="mt-16 flex flex-wrap justify-center gap-6 text-sm text-muted-foreground">
            {features.map((f) => (
              <div key={f.label} className="flex items-center gap-2">
                <f.icon className="h-4 w-4 text-primary" />
                {f.label}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Audience sections */}
      <section className="max-w-6xl mx-auto px-6 py-24">
        <div className="text-center mb-14">
          <h2 className="font-display font-bold text-3xl md:text-4xl">One platform. Every player in the game.</h2>
        </div>
        <div className="grid md:grid-cols-3 gap-5">
          {sections.map((s) => (
            <div key={s.title} className="rounded-2xl border border-border bg-card p-7 shadow-card hover:border-primary/40 transition">
              <s.icon className={`h-7 w-7 ${s.accent} mb-5`} />
              <h3 className="font-display font-semibold text-xl">{s.title}</h3>
              <p className="text-sm text-muted-foreground mt-2 leading-relaxed">{s.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="border-t border-border">
        <div className="max-w-4xl mx-auto px-6 py-20 text-center">
          <h2 className="font-display font-bold text-3xl md:text-5xl text-balance">
            Your next opportunity is one profile away.
          </h2>
          <p className="mt-4 text-muted-foreground">Free to join. Build your sports CV in minutes.</p>
          <Button asChild size="lg" className="mt-8 shadow-glow">
            <Link to="/auth/signup">Create your free profile</Link>
          </Button>
        </div>
      </section>

      <footer className="border-t border-border py-8 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} NET Athlete
      </footer>
    </div>
  );
};

export default Index;
