import { useEffect, useRef, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { Send, MessageSquare, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { EmptyState } from "@/components/EmptyState";
import { cn } from "@/lib/utils";

interface MessageRow {
  id: string;
  sender_id: string;
  receiver_id: string;
  content: string;
  created_at: string;
  read_at: string | null;
}

interface Conversation {
  otherId: string;
  otherName: string | null;
  lastMessage: string;
  lastTime: string;
  unread: number;
}

export default function Messages() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { userId } = useParams();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [messages, setMessages] = useState<MessageRow[]>([]);
  const [otherName, setOtherName] = useState<string | null>(null);
  const [text, setText] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  // Load conversations list
  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data: msgs } = await supabase
        .from("messages")
        .select("*")
        .or(`sender_id.eq.${user.id},receiver_id.eq.${user.id}`)
        .order("created_at", { ascending: false });
      if (!msgs) return;
      const map = new Map<string, Conversation>();
      for (const m of msgs as MessageRow[]) {
        const other = m.sender_id === user.id ? m.receiver_id : m.sender_id;
        if (!map.has(other)) {
          map.set(other, {
            otherId: other,
            otherName: null,
            lastMessage: m.content,
            lastTime: m.created_at,
            unread: 0,
          });
        }
        const c = map.get(other)!;
        if (m.receiver_id === user.id && !m.read_at) c.unread += 1;
      }
      const otherIds = Array.from(map.keys());
      if (otherIds.length) {
        const { data: profiles } = await supabase.from("profiles").select("id, name").in("id", otherIds);
        profiles?.forEach(p => { const c = map.get(p.id); if (c) c.otherName = p.name; });
      }
      setConversations(Array.from(map.values()));
    })();
  }, [user, messages.length]);

  // Load active thread
  useEffect(() => {
    if (!user || !userId) { setMessages([]); setOtherName(null); return; }
    (async () => {
      const { data } = await supabase
        .from("messages")
        .select("*")
        .or(`and(sender_id.eq.${user.id},receiver_id.eq.${userId}),and(sender_id.eq.${userId},receiver_id.eq.${user.id})`)
        .order("created_at", { ascending: true });
      setMessages((data as MessageRow[]) ?? []);
      const { data: p } = await supabase.from("profiles").select("name").eq("id", userId).maybeSingle();
      setOtherName(p?.name ?? null);
      // mark received as read
      await supabase.from("messages").update({ read_at: new Date().toISOString() })
        .eq("receiver_id", user.id).eq("sender_id", userId).is("read_at", null);
    })();

    const channel = supabase
      .channel(`thread-${userId}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "messages" }, (payload) => {
        const m = payload.new as MessageRow;
        if (
          (m.sender_id === user.id && m.receiver_id === userId) ||
          (m.sender_id === userId && m.receiver_id === user.id)
        ) {
          setMessages(prev => [...prev, m]);
        }
      })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [user, userId]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages.length]);

  const send = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !userId || !text.trim()) return;
    const content = text.trim().slice(0, 2000);
    setText("");
    const { error } = await supabase.from("messages").insert({
      sender_id: user.id, receiver_id: userId, content,
    });
    if (error) console.error(error);
  };

  return (
    <div className="max-w-6xl mx-auto h-[calc(100vh-3.5rem)] lg:h-screen flex">
      <aside className={cn("w-full md:w-80 border-r border-border bg-card flex flex-col", userId && "hidden md:flex")}>
        <div className="p-4 border-b border-border">
          <h2 className="font-display font-bold text-xl">Messages</h2>
        </div>
        <div className="flex-1 overflow-y-auto">
          {conversations.length === 0 ? (
            <EmptyState icon={MessageSquare} title="No conversations yet" description="Start one from a profile." />
          ) : conversations.map(c => (
            <Link key={c.otherId} to={`/messages/${c.otherId}`}
              className={cn("flex items-start gap-3 p-4 border-b border-border hover:bg-muted/30 transition",
                userId === c.otherId && "bg-muted/40")}>
              <div className="h-10 w-10 rounded-full bg-gradient-primary flex items-center justify-center text-primary-foreground font-semibold text-sm shrink-0">
                {(c.otherName ?? "?")[0]?.toUpperCase()}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex justify-between items-center gap-2">
                  <span className="font-semibold text-sm truncate">{c.otherName ?? "Unknown"}</span>
                  {c.unread > 0 && <span className="text-[10px] font-bold bg-primary text-primary-foreground rounded-full h-4 min-w-[16px] px-1 flex items-center justify-center">{c.unread}</span>}
                </div>
                <p className="text-xs text-muted-foreground truncate mt-0.5">{c.lastMessage}</p>
              </div>
            </Link>
          ))}
        </div>
      </aside>

      <section className={cn("flex-1 flex flex-col", !userId && "hidden md:flex")}>
        {!userId ? (
          <div className="flex-1 flex items-center justify-center">
            <EmptyState icon={MessageSquare} title="Select a conversation" description="Pick a chat or start one from a profile." />
          </div>
        ) : (
          <>
            <header className="h-14 border-b border-border flex items-center px-4 gap-3 bg-card">
              <Button variant="ghost" size="sm" className="md:hidden" onClick={()=>navigate("/messages")}><ArrowLeft className="h-4 w-4"/></Button>
              <Link to={`/profile/${userId}`} className="flex items-center gap-2 font-semibold hover:underline">
                {otherName ?? "Unknown"}
              </Link>
            </header>
            <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-2">
              {messages.length === 0 && <p className="text-center text-sm text-muted-foreground">No messages yet — say hi!</p>}
              {messages.map(m => {
                const mine = m.sender_id === user?.id;
                return (
                  <div key={m.id} className={cn("flex", mine ? "justify-end" : "justify-start")}>
                    <div className={cn("max-w-[75%] rounded-2xl px-4 py-2 text-sm",
                      mine ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground")}>
                      {m.content}
                    </div>
                  </div>
                );
              })}
            </div>
            <form onSubmit={send} className="border-t border-border p-3 flex gap-2">
              <Input value={text} onChange={e=>setText(e.target.value)} placeholder="Type a message…" maxLength={2000} />
              <Button type="submit"><Send className="h-4 w-4" /></Button>
            </form>
          </>
        )}
      </section>
    </div>
  );
}