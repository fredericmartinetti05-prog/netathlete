
# NET Athlete MVP — Build Plan

A sports social network for athletes, clubs, scouts, coaches and brands. Built with React + Tailwind + Lovable Cloud (Supabase) for auth, database and realtime messaging.

## Design Direction
- **Style**: Premium dark mode by default with optional light, "athletic editorial" aesthetic — inspired by Nike SNKRS, Strava, LinkedIn.
- **Palette** (HSL semantic tokens in `index.css`):
  - Background: deep navy-black `222 30% 6%`
  - Surface/cards: `222 25% 10%`
  - Primary accent: electric blue `212 100% 55%`
  - Success/level: vibrant green `142 76% 45%`
  - Alert/intensity: red `0 84% 60%`
  - Highlight/certified: yellow `45 100% 55%`
- **Typography**: Display font `Space Grotesk` (headers, bold), body `Inter`. Tabular numerals for stats.
- **Components**: rounded-2xl cards, subtle gradient borders, glow on primary CTAs, certification badge with yellow gradient.

## Tech Stack
- React + Vite + TypeScript + Tailwind + shadcn (already scaffolded)
- Lovable Cloud (Supabase) for auth, Postgres, realtime
- React Router for navigation
- React Hook Form + Zod for validation
- TanStack Query for data fetching

## Routes
```
/                      Landing
/auth/login            Login
/auth/signup           Sign up
/auth/forgot           Forgot password
/auth/reset-password   Reset password
/onboarding/role       Role selection (protected)
/dashboard             Home (protected)
/profile/edit          Edit my profile (protected)
/profile/:userId       Public profile detail
/search                Talent search (protected)
/messages              Conversation list + chat (protected)
/messages/:userId      Specific conversation
/privacy               Privacy settings (protected)
/certification         Certification request (protected)
/admin                 Admin dashboard (admin-only)
```

## Database Schema (Lovable Cloud)
- `profiles` (id=user_id PK→auth.users, name, role enum, country, city, visibility enum, certification_status enum, status, created_at, updated_at)
- `athlete_profiles` (user_id PK, sport, position, level, current_club, availability, height, weight, date_of_birth, achievements, statistics, video_links text[], sports_cv_link)
- `user_roles` (id, user_id, role app_role enum) — separate table per security guidelines; admin role lives here
- `messages` (id, sender_id, receiver_id, content, read_at, created_at) — realtime enabled
- `certification_requests` (id, user_id, status, message, document_link, reviewed_by, reviewed_at, created_at)
- `reports` (id, reporter_id, reported_user_id, reason, status, created_at, resolved_at)
- Placeholder tables: `opportunities`, `events`, `marketplace_items` (with minimal columns)
- `has_role(uuid, app_role)` security definer function
- RLS on every table; trigger to auto-create profile row on signup
- GRANTs on every public table per platform requirement

## Key Components (reusable)
- `AthleteCard`, `ProfileHeader`, `CertificationBadge`, `RoleBadge`, `FilterPanel`, `StatBlock`, `EmptyState`, `ProtectedRoute`, `AdminRoute`, `ChatBubble`, `ConversationList`, `AppShell` (sidebar + header).

## MVP Behavior
- Auth: email/password, signup → role selection → onboarding → dashboard
- Talent search: filter by sport, position, age (computed from DOB), country, city, level, availability, has_video — using Postgres queries; respects visibility (only `public` profiles visible to non-owners/non-admins, `connections_only` shows limited card, `private` hidden)
- Messaging: realtime via Supabase channels with fallback fetch
- Certification: user submits → admin approves/rejects → badge appears
- Admin dashboard: tables for users, certifications, reports with approve/reject actions
- Empty states and Zod validation throughout
- Sample seed via SQL inserts so the search page isn't empty on first load

## Out of Scope (placeholders only)
Opportunities/events/marketplace UIs, connections/follow logic, notifications, payments, advanced verification, full report submission flow (admin side ready, user submission minimal).

## Deliverable
Working MVP with all routes, schema, RLS, auth flows, search, messaging, certification and admin dashboard.
